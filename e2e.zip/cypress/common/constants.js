export default {
    nav: {
        index: '#/',
        login: '#/login',
        signup: '#/signup',
        sections: '#/sections'
    }
};